# common_redshift.py
import json
import time
import re
from datetime import datetime, timezone

import boto3

# ====== CONFIG BÁSICA (ajusta el nombre del workgroup una sola vez) ======
WORKGROUP_NAME = "dl-workgroup-dev-rs"   # <-- tu workgroup serverless
SECRET_NAME    = "redshift/finandina/dev"  # <-- tu secreto (por nombre, no ARN)
# ========================================================================

rds = boto3.client("redshift-data")
secrets = boto3.client("secretsmanager")

DEFAULT_WAIT_SECONDS = 2
DEFAULT_TIMEOUT_SEC  = 900  # 15 min

# Cache en frío de Lambda
__SECRET_ARN = None
__DB_NAME = None

class RedshiftError(RuntimeError):
    pass

def _now_iso():
    return datetime.now(timezone.utc).isoformat()

def _parse_db_from_host(host: str) -> str | None:
    """
    En tu captura, el host trae ...:5439/dl_dev
    Extrae 'dl_dev' si no viene 'dbname' en el secreto.
    """
    if not host:
        return None
    m = re.search(r":\d+/(.+)$", host)
    return m.group(1) if m else None

def _load_secret():
    """
    Carga y cachea:
      - ARN del secreto (para Data API)
      - nombre de base de datos (dbname) desde el secreto (o lo infiere del host)
    """
    global __SECRET_ARN, __DB_NAME
    if __SECRET_ARN and __DB_NAME:
        return

    # 1) Resolver ARN del secreto
    desc = secrets.describe_secret(SecretId=SECRET_NAME)
    __SECRET_ARN = desc["ARN"]

    # 2) Leer valores del secreto
    gv = secrets.get_secret_value(SecretId=SECRET_NAME)
    payload = gv.get("SecretString")
    if not payload:
        raise RedshiftError("El secreto no tiene SecretString")
    data = json.loads(payload)

    # 3) dbname directo o inferido
    dbname = data.get("dbname")
    if not dbname:
        dbname = _parse_db_from_host(data.get("host", ""))

    if not dbname:
        raise RedshiftError("No se pudo determinar el nombre de la base (dbname). Agrega 'dbname' al secreto o usa host con '/<db>'.")

    __DB_NAME = dbname

def exec_statement(sql: str) -> dict:
    """
    Ejecuta SQL vía Data API usando SecretArn + WorkgroupName + Database (del secreto).
    Retorna: {'status','rowcount','statement_id','records'[]}
    """
    _load_secret()

    resp = rds.execute_statement(
        SecretArn=__SECRET_ARN,
        WorkgroupName=WORKGROUP_NAME,
        Database=__DB_NAME,
        Sql=sql
    )
    sid = resp["Id"]

    start = time.time()
    while True:
        d = rds.describe_statement(Id=sid)
        st = d["Status"]
        if st in ("FINISHED", "FAILED", "ABORTED"):
            break
        if time.time() - start > DEFAULT_TIMEOUT_SEC:
            raise RedshiftError(f"Timeout esperando statement {sid}")
        time.sleep(DEFAULT_WAIT_SECONDS)

    if st != "FINISHED":
        raise RedshiftError(f"Statement {sid} terminó en {st}. Error: {d.get('Error','')}")

    out = {"status": st, "rowcount": d.get("ResultSize", 0), "statement_id": sid}

    if d.get("HasResultSet"):
        recs = []
        next_token = None
        while True:
            args = {"Id": sid}
            if next_token:
                args["NextToken"] = next_token
            res = rds.get_statement_result(**args)
            recs.extend(res.get("Records", []))
            next_token = res.get("NextToken")
            if not next_token:
                break
        out["records"] = recs
    else:
        out["records"] = []

    return out

def fetch_one_value(records, default=None):
    if not records:
        return default
    cell = records[0][0]
    for k in ("stringValue","longValue","doubleValue","booleanValue"):
        if k in cell:
            return cell[k]
    return default

def call_sp_positional(sp_qualified_name: str, args: list):
    """
    Llama a un SP con parámetros posicionales.
    """
    literal_args = []
    for a in args:
        if a is None:
            literal_args.append("NULL")
        elif isinstance(a, (int, float)):
            literal_args.append(str(a))
        else:
            s = str(a).replace("'", "''")
            literal_args.append(f"'{s}'")
    sql = f"CALL {sp_qualified_name}({', '.join(literal_args)});"
    return exec_statement(sql)

def to_int_safe(v, default=0):
    try:
        return int(v)
    except Exception:
        return default
